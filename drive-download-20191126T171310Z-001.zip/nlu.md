
## intent:greet
- Good Morning
- good morning
- Good morning
- good Morning
- gud mng
- gud morning
- good mng
- good mrng
- gud mrng
- Good Evening
- Good evening
- Gud evng
- Gud Evng
- good evening
- good Evening
- Good Afternoon
- Good afternoon
- good after noon
- Good After Noon
- gud afternoon
- Gud aftr noon

##intent:name
 - Iam fathima
 - Iam Anu
 - Iam Afru
 - Iam shyam
 - Iam Rahul
 - Myself Raj
 - Myself ajeeb
 - myself neha
 - myself naja
 - myself ashi
 - my name is aju
 - my name is swathi
 - my name is mariya
 - my name is varsha

##intent:designation
 - Iam currently pursuing MCA at CET
 - Iam a mca student at CET
 - Iam a final year mca student at cet.
 - Iam a mca graduate at cet.
 - Iam currently doing mca at Cet
 - Iam doing mca at cet
 - Iam studying mca at cet

##intent:strength
 - Iam good at programming
 - Iam good at problem solving
 - Iam good at organizing
 - iam good at time management
 - Iam good as team leader
 - Iam creative
 - Iam adaptable
 - Iam good at communication.
## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:mood_great
- perfect
- very good
- great
- amazing
- wonderful
- I am feeling very good
- I am great
- I'm good

## intent:mood_unhappy
- sad
- very sad
- unhappy
- bad
- very bad
- awful
- terrible
- not very good
- extremely sad
- so sad
